USE Fidelia;
SELECT ID_Modele_Message, Titre_Modele_Message, Corps_Modele_Message, Objet_Modele_Message, Type_Modele_Message, Categorie_Modele_Message, Date_Modele_Message FROM modele_message m  WHERE m.ID_Modele_Message = 1;
